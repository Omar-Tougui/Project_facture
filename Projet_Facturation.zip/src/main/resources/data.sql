-- Données de test pour le projet
INSERT INTO clients (nom, email, siret, date_creation) VALUES 
('Entreprise Martin', 'contact@martin-entreprise.fr', '12345678901234', '2024-01-15 10:00:00'),
('SARL Dupont', 'info@dupont-sarl.com', '23456789012345', '2024-02-20 14:30:00'),
('SAS Moreau', 'admin@moreau-sas.fr', '34567890123456', '2024-03-10 09:15:00');

INSERT INTO factures (client_id, date_facture, total_ht, total_tva, total_ttc) VALUES 
(1, '2024-06-01', 1000.00, 200.00, 1200.00),
(1, '2024-06-15', 500.00, 100.00, 600.00),
(2, '2024-06-10', 750.00, 82.50, 832.50),
(3, '2024-06-20', 2000.00, 400.00, 2400.00);

INSERT INTO lignes_facture (facture_id, description, quantite, prix_unitaire_ht, taux_tva, total_ht, total_tva, total_ttc) VALUES 
(1, 'Développement site web', 10, 80.00, 'NORMAL', 800.00, 160.00, 960.00),
(1, 'Formation équipe', 4, 50.00, 'NORMAL', 200.00, 40.00, 240.00),
(2, 'Maintenance système', 5, 100.00, 'NORMAL', 500.00, 100.00, 600.00),
(3, 'Conseil technique', 15, 50.00, 'REDUIT_2', 750.00, 75.00, 825.00),
(3, 'Déplacement', 1, 7.50, 'REDUIT_2', 7.50, 0.75, 8.25),
(4, 'Audit complet', 20, 100.00, 'NORMAL', 2000.00, 400.00, 2400.00);
