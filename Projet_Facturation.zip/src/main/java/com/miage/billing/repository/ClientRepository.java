package com.miage.billing.repository;

import com.miage.billing.entity.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository pour la gestion des clients
 * Fournit les méthodes d'accès aux données pour l'entité Client
 */
@Repository
public interface ClientRepository extends JpaRepository<Client, Long> {
    
    /**
     * Recherche un client par son email
     * @param email l'email du client
     * @return Optional contenant le client s'il existe
     */
    Optional<Client> findByEmail(String email);
    
    /**
     * Recherche un client par son SIRET
     * @param siret le SIRET du client
     * @return Optional contenant le client s'il existe
     */
    Optional<Client> findBySiret(String siret);
    
    /**
     * Vérifie si un email existe déjà
     * @param email l'email à vérifier
     * @return true si l'email existe
     */
    boolean existsByEmail(String email);
    
    /**
     * Vérifie si un SIRET existe déjà
     * @param siret le SIRET à vérifier
     * @return true si le SIRET existe
     */
    boolean existsBySiret(String siret);
    
    /**
     * Recherche des clients par nom (insensible à la casse)
     * @param nom le nom à rechercher
     * @return liste des clients correspondants
     */
    @Query("SELECT c FROM Client c WHERE LOWER(c.nom) LIKE LOWER(CONCAT('%', :nom, '%'))")
    java.util.List<Client> findByNomContainingIgnoreCase(@Param("nom") String nom);
}
