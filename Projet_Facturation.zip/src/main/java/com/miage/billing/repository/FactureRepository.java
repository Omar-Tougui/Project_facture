package com.miage.billing.repository;

import com.miage.billing.entity.Facture;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Repository pour la gestion des factures
 * Fournit les méthodes d'accès aux données pour l'entité Facture
 */
@Repository
public interface FactureRepository extends JpaRepository<Facture, Long> {
    
    /**
     * Recherche les factures d'un client spécifique
     * @param clientId l'ID du client
     * @return liste des factures du client
     */
    @Query("SELECT f FROM Facture f WHERE f.client.id = :clientId ORDER BY f.dateFacture DESC")
    List<Facture> findByClientId(@Param("clientId") Long clientId);
    
    /**
     * Recherche les factures par période
     * @param dateDebut date de début
     * @param dateFin date de fin
     * @return liste des factures dans la période
     */
    @Query("SELECT f FROM Facture f WHERE f.dateFacture BETWEEN :dateDebut AND :dateFin ORDER BY f.dateFacture DESC")
    List<Facture> findByDateFactureBetween(@Param("dateDebut") LocalDate dateDebut, 
                                          @Param("dateFin") LocalDate dateFin);
    
    /**
     * Recherche les factures d'un client dans une période donnée
     * @param clientId l'ID du client
     * @param dateDebut date de début
     * @param dateFin date de fin
     * @return liste des factures correspondantes
     */
    @Query("SELECT f FROM Facture f WHERE f.client.id = :clientId AND f.dateFacture BETWEEN :dateDebut AND :dateFin ORDER BY f.dateFacture DESC")
    List<Facture> findByClientIdAndDateFactureBetween(@Param("clientId") Long clientId,
                                                     @Param("dateDebut") LocalDate dateDebut,
                                                     @Param("dateFin") LocalDate dateFin);
    
    /**
     * Compte le nombre de factures d'un client
     * @param clientId l'ID du client
     * @return nombre de factures
     */
    long countByClientId(Long clientId);
}
