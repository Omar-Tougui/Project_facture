package com.miage.billing.mapper;

import com.miage.billing.dto.ClientDTO;
import com.miage.billing.entity.Client;
import org.springframework.stereotype.Component;

/**
 * Mapper pour convertir entre Client et ClientDTO
 * Centralise la logique de conversion
 */
@Component
public class ClientMapper {
    
    /**
     * Convertit une entité Client en DTO
     * @param client l'entité à convertir
     * @return le DTO correspondant
     */
    public ClientDTO toDTO(Client client) {
        if (client == null) {
            return null;
        }
        
        ClientDTO dto = new ClientDTO();
        dto.setId(client.getId());
        dto.setNom(client.getNom());
        dto.setEmail(client.getEmail());
        dto.setSiret(client.getSiret());
        dto.setDateCreation(client.getDateCreation());
        
        return dto;
    }
    
    /**
     * Convertit un DTO en entité Client
     * @param dto le DTO à convertir
     * @return l'entité correspondante
     */
    public Client toEntity(ClientDTO dto) {
        if (dto == null) {
            return null;
        }
        
        Client client = new Client();
        client.setId(dto.getId());
        client.setNom(dto.getNom());
        client.setEmail(dto.getEmail());
        client.setSiret(dto.getSiret());
        if (dto.getDateCreation() != null) {
            client.setDateCreation(dto.getDateCreation());
        }
        
        return client;
    }
    
    /**
     * Met à jour une entité existante avec les données du DTO
     * @param client l'entité à mettre à jour
     * @param dto les nouvelles données
     */
    public void updateEntity(Client client, ClientDTO dto) {
        if (client != null && dto != null) {
            client.setNom(dto.getNom());
            client.setEmail(dto.getEmail());
            client.setSiret(dto.getSiret());
        }
    }
}
