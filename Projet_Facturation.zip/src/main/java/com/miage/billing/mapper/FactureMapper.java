package com.miage.billing.mapper;

import com.miage.billing.dto.FactureDTO;
import com.miage.billing.dto.LigneFactureDTO;
import com.miage.billing.entity.Facture;
import com.miage.billing.entity.LigneFacture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Mapper pour convertir entre Facture et FactureDTO
 * Gère également la conversion des lignes de facture
 */
@Component
public class FactureMapper {
    
    @Autowired
    private ClientMapper clientMapper;
    
    /**
     * Convertit une entité Facture en DTO
     * @param facture l'entité à convertir
     * @return le DTO correspondant
     */
    public FactureDTO toDTO(Facture facture) {
        if (facture == null) {
            return null;
        }
        
        FactureDTO dto = new FactureDTO();
        dto.setId(facture.getId());
        dto.setClientId(facture.getClient().getId());
        dto.setClient(clientMapper.toDTO(facture.getClient()));
        dto.setDateFacture(facture.getDateFacture());
        dto.setTotalHT(facture.getTotalHT());
        dto.setTotalTVA(facture.getTotalTVA());
        dto.setTotalTTC(facture.getTotalTTC());
        
        // Conversion des lignes
        List<LigneFactureDTO> lignesDTO = facture.getLignes().stream()
                .map(this::ligneToDTO)
                .collect(Collectors.toList());
        dto.setLignes(lignesDTO);
        
        return dto;
    }
    
    /**
     * Convertit une LigneFacture en DTO
     * @param ligne l'entité à convertir
     * @return le DTO correspondant
     */
    public LigneFactureDTO ligneToDTO(LigneFacture ligne) {
        if (ligne == null) {
            return null;
        }
        
        LigneFactureDTO dto = new LigneFactureDTO();
        dto.setId(ligne.getId());
        dto.setDescription(ligne.getDescription());
        dto.setQuantite(ligne.getQuantite());
        dto.setPrixUnitaireHT(ligne.getPrixUnitaireHT());
        dto.setTauxTVA(ligne.getTauxTVA());
        dto.setTotalHT(ligne.getTotalHT());
        dto.setTotalTVA(ligne.getTotalTVA());
        dto.setTotalTTC(ligne.getTotalTTC());
        
        return dto;
    }
    
    /**
     * Convertit un DTO en entité LigneFacture
     * @param dto le DTO à convertir
     * @return l'entité correspondante
     */
    public LigneFacture dtoToLigne(LigneFactureDTO dto) {
        if (dto == null) {
            return null;
        }
        
        return new LigneFacture(
            dto.getDescription(),
            dto.getQuantite(),
            dto.getPrixUnitaireHT(),
            dto.getTauxTVA()
        );
    }
}
