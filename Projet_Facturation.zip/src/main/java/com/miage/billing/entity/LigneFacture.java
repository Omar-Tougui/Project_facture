package com.miage.billing.entity;

import com.miage.billing.enums.TauxTVA;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Entité représentant une ligne de facture
 * Contient le détail d'un produit/service facturé avec calculs automatiques
 */
@Entity
@Table(name = "lignes_facture")
public class LigneFacture {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "La description est obligatoire")
    @Column(nullable = false)
    private String description;
    
    @NotNull(message = "La quantité est obligatoire")
    @Positive(message = "La quantité doit être positive")
    @Column(nullable = false)
    private Integer quantite;
    
    @NotNull(message = "Le prix unitaire HT est obligatoire")
    @DecimalMin(value = "0.0", inclusive = false, message = "Le prix unitaire doit être positif")
    @Column(name = "prix_unitaire_ht", nullable = false, precision = 10, scale = 2)
    private BigDecimal prixUnitaireHT;
    
    @NotNull(message = "Le taux de TVA est obligatoire")
    @Enumerated(EnumType.STRING)
    @Column(name = "taux_tva", nullable = false)
    private TauxTVA tauxTVA;
    
    // Relation ManyToOne avec Facture
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "facture_id", nullable = false)
    private Facture facture;
    
    // Totaux calculés
    @Column(name = "total_ht", precision = 10, scale = 2)
    private BigDecimal totalHT;
    
    @Column(name = "total_tva", precision = 10, scale = 2)
    private BigDecimal totalTVA;
    
    @Column(name = "total_ttc", precision = 10, scale = 2)
    private BigDecimal totalTTC;
    
    // Constructeurs
    public LigneFacture() {}
    
    public LigneFacture(String description, Integer quantite, BigDecimal prixUnitaireHT, TauxTVA tauxTVA) {
        this.description = description;
        this.quantite = quantite;
        this.prixUnitaireHT = prixUnitaireHT;
        this.tauxTVA = tauxTVA;
        calculerTotaux();
    }
    
    // Getters et Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public Integer getQuantite() { return quantite; }
    public void setQuantite(Integer quantite) { 
        this.quantite = quantite;
        calculerTotaux();
    }
    
    public BigDecimal getPrixUnitaireHT() { return prixUnitaireHT; }
    public void setPrixUnitaireHT(BigDecimal prixUnitaireHT) { 
        this.prixUnitaireHT = prixUnitaireHT;
        calculerTotaux();
    }
    
    public TauxTVA getTauxTVA() { return tauxTVA; }
    public void setTauxTVA(TauxTVA tauxTVA) { 
        this.tauxTVA = tauxTVA;
        calculerTotaux();
    }
    
    public Facture getFacture() { return facture; }
    public void setFacture(Facture facture) { this.facture = facture; }
    
    public BigDecimal getTotalHT() { return totalHT; }
    public BigDecimal getTotalTVA() { return totalTVA; }
    public BigDecimal getTotalTTC() { return totalTTC; }
    
    /**
     * Calcule automatiquement les totaux de la ligne
     * Appelé automatiquement lors des modifications
     */
    private void calculerTotaux() {
        if (quantite != null && prixUnitaireHT != null && tauxTVA != null) {
            totalHT = prixUnitaireHT.multiply(BigDecimal.valueOf(quantite))
                     .setScale(2, RoundingMode.HALF_UP);
            
            totalTVA = totalHT.multiply(tauxTVA.getValeur())
                      .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
            
            totalTTC = totalHT.add(totalTVA);
        }
    }
}
