package com.miage.billing.service;

import com.miage.billing.dto.FactureDTO;
import com.miage.billing.dto.LigneFactureDTO;
import com.miage.billing.entity.Client;
import com.miage.billing.entity.Facture;
import com.miage.billing.entity.LigneFacture;
import com.miage.billing.exception.BusinessException;
import com.miage.billing.exception.ResourceNotFoundException;
import com.miage.billing.mapper.FactureMapper;
import com.miage.billing.repository.ClientRepository;
import com.miage.billing.repository.FactureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class FactureService {
    
    @Autowired
    private FactureRepository factureRepository;
    
    @Autowired
    private ClientRepository clientRepository;
    
    @Autowired
    private FactureMapper factureMapper;
    
    @Transactional(readOnly = true)
    public List<FactureDTO> getAllFactures() {
        return factureRepository.findAll().stream()
                .map(factureMapper::toDTO)
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public FactureDTO getFactureById(Long id) {
        Facture facture = factureRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Facture non trouvée avec l'ID: " + id));
        return factureMapper.toDTO(facture);
    }
    
    public FactureDTO createFacture(FactureDTO factureDTO) {
        // Vérifications des données
        this.verifierFacture(factureDTO);
        
        // Le client doit exister
        Client client = clientRepository.findById(factureDTO.getClientId())
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + factureDTO.getClientId()));
        
        // Création de la facture
        Facture facture = new Facture(client, factureDTO.getDateFacture());
        
        // Ajout des lignes de facture
        for (LigneFactureDTO ligneDTO : factureDTO.getLignes()) {
            LigneFacture ligne = factureMapper.dtoToLigne(ligneDTO);
            facture.ajouterLigne(ligne);
        }
        
        // Calcul des totaux (important !)
        facture.calculerTotaux();
        
        Facture savedFacture = factureRepository.save(facture);
        
        return factureMapper.toDTO(savedFacture);
    }
    
    @Transactional(readOnly = true)
    public List<FactureDTO> getFacturesByClient(Long clientId) {
        // Vérifier que le client existe
        if (!clientRepository.existsById(clientId)) {
            throw new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId);
        }
        
        return factureRepository.findByClientId(clientId).stream()
                .map(factureMapper::toDTO)
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public List<FactureDTO> getFacturesByPeriod(LocalDate dateDebut, LocalDate dateFin) {
        if (dateDebut.isAfter(dateFin)) {
            throw new BusinessException("La date de début doit être antérieure à la date de fin");
        }
        
        return factureRepository.findByDateFactureBetween(dateDebut, dateFin).stream()
                .map(factureMapper::toDTO)
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public List<FactureDTO> getFacturesByClientAndPeriod(Long clientId, LocalDate dateDebut, LocalDate dateFin) {
        if (!clientRepository.existsById(clientId)) {
            throw new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId);
        }
        
        if (dateDebut.isAfter(dateFin)) {
            throw new BusinessException("La date de début doit être antérieure à la date de fin");
        }
        
        return factureRepository.findByClientIdAndDateFactureBetween(clientId, dateDebut, dateFin).stream()
                .map(factureMapper::toDTO)
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public FactureDTO exportFactureToJson(Long id) {
        return getFactureById(id);
    }
    
    // Méthode pour vérifier les données de la facture
    private void verifierFacture(FactureDTO factureDTO) {
        if (factureDTO.getClientId() == null) {
            throw new BusinessException("L'ID du client est obligatoire");
        }
        
        if (factureDTO.getDateFacture() == null) {
            throw new BusinessException("La date de facture est obligatoire");
        }
        
        if (factureDTO.getLignes() == null || factureDTO.getLignes().isEmpty()) {
            throw new BusinessException("Une facture doit avoir au moins une ligne");
        }
        
        // Vérifier chaque ligne
        for (LigneFactureDTO ligne : factureDTO.getLignes()) {
            this.verifierLigneFacture(ligne);
        }
    }
    
    // Vérification d'une ligne de facture
    private void verifierLigneFacture(LigneFactureDTO ligne) {
        if (ligne.getDescription() == null || ligne.getDescription().trim().isEmpty()) {
            throw new BusinessException("La description de la ligne ne peut pas être vide");
        }
        
        if (ligne.getQuantite() == null || ligne.getQuantite() <= 0) {
            throw new BusinessException("La quantité doit être positive");
        }
        
        if (ligne.getPrixUnitaireHT() == null || ligne.getPrixUnitaireHT().compareTo(java.math.BigDecimal.ZERO) <= 0) {
            throw new BusinessException("Le prix unitaire HT doit être positif");
        }
        
        if (ligne.getTauxTVA() == null) {
            throw new BusinessException("Le taux de TVA est obligatoire");
        }
    }
}
