package com.miage.billing.service;

import com.miage.billing.dto.ClientDTO;
import com.miage.billing.entity.Client;
import com.miage.billing.exception.BusinessException;
import com.miage.billing.exception.ResourceNotFoundException;
import com.miage.billing.mapper.ClientMapper;
import com.miage.billing.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ClientService {
    
    @Autowired
    private ClientRepository clientRepository;
    
    @Autowired
    private ClientMapper clientMapper;
    
    @Transactional(readOnly = true)
    public List<ClientDTO> getAllClients() {
        return clientRepository.findAll().stream()
                .map(clientMapper::toDTO)
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public ClientDTO getClientById(Long id) {
        Client client = clientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + id));
        return clientMapper.toDTO(client);
    }
    
    public ClientDTO createClient(ClientDTO clientDTO) {
        // Vérifications avant création
        this.verifierDonneesClient(clientDTO);
        
        if (clientRepository.existsByEmail(clientDTO.getEmail())) {
            throw new BusinessException("Un client avec cet email existe déjà: " + clientDTO.getEmail());
        }
        
        if (clientRepository.existsBySiret(clientDTO.getSiret())) {
            throw new BusinessException("Un client avec ce SIRET existe déjà: " + clientDTO.getSiret());
        }
        
        Client client = clientMapper.toEntity(clientDTO);
        Client savedClient = clientRepository.save(client);
        
        return clientMapper.toDTO(savedClient);
    }
    
    public ClientDTO updateClient(Long id, ClientDTO clientDTO) {
        Client existingClient = clientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + id));
        
        this.verifierDonneesClient(clientDTO);
        
        // Vérifier que l'email n'est pas déjà utilisé par un autre client
        if (!existingClient.getEmail().equals(clientDTO.getEmail()) && 
            clientRepository.existsByEmail(clientDTO.getEmail())) {
            throw new BusinessException("Un autre client avec cet email existe déjà: " + clientDTO.getEmail());
        }
        
        // Même chose pour le SIRET
        if (!existingClient.getSiret().equals(clientDTO.getSiret()) && 
            clientRepository.existsBySiret(clientDTO.getSiret())) {
            throw new BusinessException("Un autre client avec ce SIRET existe déjà: " + clientDTO.getSiret());
        }
        
        clientMapper.updateEntity(existingClient, clientDTO);
        Client updatedClient = clientRepository.save(existingClient);
        
        return clientMapper.toDTO(updatedClient);
    }
    
    public void deleteClient(Long id) {
        if (!clientRepository.existsById(id)) {
            throw new ResourceNotFoundException("Client non trouvé avec l'ID: " + id);
        }
        
        clientRepository.deleteById(id);
    }
    
    @Transactional(readOnly = true)
    public List<ClientDTO> searchClientsByName(String nom) {
        return clientRepository.findByNomContainingIgnoreCase(nom).stream()
                .map(clientMapper::toDTO)
                .collect(Collectors.toList());
    }
    
    // Méthode privée pour valider les données
    private void verifierDonneesClient(ClientDTO clientDTO) {
        if (clientDTO.getNom() == null || clientDTO.getNom().trim().isEmpty()) {
            throw new BusinessException("Le nom du client ne peut pas être vide");
        }
        
        if (clientDTO.getEmail() == null || clientDTO.getEmail().trim().isEmpty()) {
            throw new BusinessException("L'email du client ne peut pas être vide");
        }
        
        if (clientDTO.getSiret() == null || clientDTO.getSiret().trim().isEmpty()) {
            throw new BusinessException("Le SIRET du client ne peut pas être vide");
        }
        
        // J'ai appris que le SIRET doit faire exactement 14 chiffres
        if (!clientDTO.getSiret().matches("\\d{14}")) {
            throw new BusinessException("Le SIRET doit contenir exactement 14 chiffres");
        }
    }
}
