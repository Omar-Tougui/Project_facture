package com.miage.billing.enums;

import java.math.BigDecimal;

/**
 * Énumération des taux de TVA autorisés
 * Respecte les taux français en vigueur
 */
public enum TauxTVA {
    ZERO(BigDecimal.ZERO, "0%"),
    REDUIT_1(new BigDecimal("5.5"), "5.5%"),
    REDUIT_2(new BigDecimal("10"), "10%"),
    NORMAL(new BigDecimal("20"), "20%");
    
    private final BigDecimal valeur;
    private final String libelle;
    
    TauxTVA(BigDecimal valeur, String libelle) {
        this.valeur = valeur;
        this.libelle = libelle;
    }
    
    public BigDecimal getValeur() {
        return valeur;
    }
    
    public String getLibelle() {
        return libelle;
    }
    
    @Override
    public String toString() {
        return libelle;
    }
}
