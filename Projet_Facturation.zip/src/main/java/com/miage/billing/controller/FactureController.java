package com.miage.billing.controller;

import com.miage.billing.dto.FactureDTO;
import com.miage.billing.service.FactureService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/factures")
public class FactureController {
    
    @Autowired
    private FactureService factureService;
    
    @GetMapping
    public ResponseEntity<List<FactureDTO>> getAllFactures() {
        List<FactureDTO> factures = factureService.getAllFactures();
        return ResponseEntity.ok(factures);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<FactureDTO> getFactureById(@PathVariable Long id) {
        FactureDTO facture = factureService.getFactureById(id);
        return ResponseEntity.ok(facture);
    }
    
    @PostMapping
    public ResponseEntity<FactureDTO> createFacture(@Valid @RequestBody FactureDTO factureDTO) {
        FactureDTO createdFacture = factureService.createFacture(factureDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdFacture);
    }
    
    @GetMapping("/client/{clientId}")
    public ResponseEntity<List<FactureDTO>> getFacturesByClient(@PathVariable Long clientId) {
        List<FactureDTO> factures = factureService.getFacturesByClient(clientId);
        return ResponseEntity.ok(factures);
    }
    
    @GetMapping("/search/period")
    public ResponseEntity<List<FactureDTO>> getFacturesByPeriod(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateDebut,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFin) {
        List<FactureDTO> factures = factureService.getFacturesByPeriod(dateDebut, dateFin);
        return ResponseEntity.ok(factures);
    }
    
    @GetMapping("/search/client-period")
    public ResponseEntity<List<FactureDTO>> getFacturesByClientAndPeriod(
            @RequestParam Long clientId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateDebut,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFin) {
        List<FactureDTO> factures = factureService.getFacturesByClientAndPeriod(clientId, dateDebut, dateFin);
        return ResponseEntity.ok(factures);
    }
    
    @GetMapping("/{id}/export")
    public ResponseEntity<FactureDTO> exportFacture(@PathVariable Long id) {
        FactureDTO facture = factureService.exportFactureToJson(id);
        return ResponseEntity.ok(facture);
    }
}
