package com.miage.billing.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * DTO pour les factures
 * Utilisé pour la création et l'affichage des factures
 */
public class FactureDTO {
    
    private Long id;
    
    @NotNull(message = "L'ID du client est obligatoire")
    private Long clientId;
    
    private ClientDTO client; // Pour l'affichage
    
    @NotNull(message = "La date de facture est obligatoire")
    private LocalDate dateFacture;
    
    @NotEmpty(message = "Une facture doit avoir au moins une ligne")
    @Valid
    private List<LigneFactureDTO> lignes;
    
    // Totaux calculés (lecture seule)
    private BigDecimal totalHT;
    private BigDecimal totalTVA;
    private BigDecimal totalTTC;
    
    // Constructeurs
    public FactureDTO() {}
    
    public FactureDTO(Long clientId, LocalDate dateFacture, List<LigneFactureDTO> lignes) {
        this.clientId = clientId;
        this.dateFacture = dateFacture;
        this.lignes = lignes;
    }
    
    // Getters et Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Long getClientId() { return clientId; }
    public void setClientId(Long clientId) { this.clientId = clientId; }
    
    public ClientDTO getClient() { return client; }
    public void setClient(ClientDTO client) { this.client = client; }
    
    public LocalDate getDateFacture() { return dateFacture; }
    public void setDateFacture(LocalDate dateFacture) { this.dateFacture = dateFacture; }
    
    public List<LigneFactureDTO> getLignes() { return lignes; }
    public void setLignes(List<LigneFactureDTO> lignes) { this.lignes = lignes; }
    
    public BigDecimal getTotalHT() { return totalHT; }
    public void setTotalHT(BigDecimal totalHT) { this.totalHT = totalHT; }
    
    public BigDecimal getTotalTVA() { return totalTVA; }
    public void setTotalTVA(BigDecimal totalTVA) { this.totalTVA = totalTVA; }
    
    public BigDecimal getTotalTTC() { return totalTTC; }
    public void setTotalTTC(BigDecimal totalTTC) { this.totalTTC = totalTTC; }
}
